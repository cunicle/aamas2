source /workspace/aamas2_env.sh
cd /workspace/aamas2
bash scripts/run_minimal.sh smoke > /workspace/aamas2_logs/smoke_run3.log 2>&1
D=/workspace/aamas2_diag/mini2; rm -rf $D; mkdir -p $D
M="--data bfcl:parallel --data bfcl:parallel_multiple --per-data 10 --mode skeleton --k 1,4"
$PY_DREAM scripts/run_dllm.py --model Dream-org/Dream-v0-Instruct-7B $M --out $D/dream.jsonl > $D/dream.log 2>&1
$PY_LLADA2 scripts/run_dllm.py --model inclusionAI/LLaDA2.0-mini $M --block-length 32 --out $D/llada2.jsonl > $D/llada2.log 2>&1
touch $D/DONE
