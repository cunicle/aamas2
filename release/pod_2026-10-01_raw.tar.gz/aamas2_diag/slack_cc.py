"""Diagnostic: are the cross-call errors in slots with surplus masks?"""
import json, sys
sys.path.insert(0, "/workspace/aamas2"); sys.path.insert(0, "/workspace/aamas2_diag")
sys.argv = [sys.argv[0], sys.argv[1]] + sys.argv[2:]
import slack_check as sc  # prints its table on import; fine
from ptcdiag.eval.taxonomy import CROSS_CALL
for path in sys.argv[2:]:
    for line in open(path):
        r = json.loads(line)
        ex = sc.exs[r["id"]]; sl = sc.slack(ex); m = dict(r["diagnosis"]["matching"])
        for d in r["diagnosis"]["details"]:
            if d["label"] not in CROSS_CALL: continue
            if "param" in d and "gold" in d:
                hit = sl.get((d["gold"], d["param"]), 0) > 0
            elif d["label"] == "duplicate_call":
                golds = {m.get(p) for p in d.get("preds", [])} - {None}
                hit = any(v > 0 for (g, p), v in sl.items() if g in golds)
            elif "param" in d:
                hit = any(v > 0 for (g, p), v in sl.items() if p == d["param"])
            else:
                hit = any(v > 0 for v in sl.values())
            print(f"CC {r['cfg_tag'][:14]} {r['id']:22s} {d['label']:24s} slack={hit}")
