"""Diagnostic: share of same-parameter slot pairs (different calls) sharing a 32-token block."""
import sys
sys.path.insert(0, "/workspace/aamas2")
from transformers import AutoTokenizer
from ptcdiag.data import load_examples
from ptcdiag.decoding.constraints import SLOT_LENGTHS, build_skeleton
from ptcdiag.prompting import render_prompt
tok = AutoTokenizer.from_pretrained("inclusionAI/LLaDA2.0-mini", trust_remote_code=True)
B = 32
for spec in ("bfcl:parallel,parallel_multiple", "probe:data/paraprobe.jsonl"):
    exs = load_examples(spec, "data/bfcl")
    for name, sl in (("fixed lengths (old)", SLOT_LENGTHS), ("exact lengths (now)", None)):
        pairs = shared = 0
        for e in exs:
            P = len(tok(render_prompt(tok, e), add_special_tokens=False)["input_ids"])
            _, slots = build_skeleton(tok, e, 156895, sl)
            blocks = {id(s): {(P + g) // B for g in s.positions} for s in slots}
            for i, a in enumerate(slots):
                for b in slots[i + 1:]:
                    if a.param == b.param and a.call != b.call:
                        pairs += 1
                        shared += bool(blocks[id(a)] & blocks[id(b)])
        print(f"{spec:32s} {name}: {shared}/{pairs} = {shared / max(pairs, 1):.3f}")
