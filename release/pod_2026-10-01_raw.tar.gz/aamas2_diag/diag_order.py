"""Diagnostic (not part of the repo): commit order of a dLLM inside value slots."""
import sys

sys.path.insert(0, "/workspace/aamas2")
from ptcdiag.data import load_examples
from ptcdiag.decoding.adapters import load_adapter
from ptcdiag.decoding.sampler import DecodeConfig
from ptcdiag.pipeline import make_constraint, run_example

model, n = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 1
block = int(sys.argv[3]) if len(sys.argv) > 3 else None
a = load_adapter(model)
for ex in load_examples("bfcl:parallel", "data/bfcl")[:n]:
    for k, order, show in ((2, "confidence", True), (1, "confidence", False), (1, "left_to_right", False)):
        rec = run_example(a, ex, DecodeConfig(gen_length=256, k=k, order=order, block_length=block), "skeleton")
        c = make_constraint(a, ex, "skeleton")
        c.initial_gen(10 ** 4, rec["prompt_len"])
        where = {c.P + g: (s.call, s.param, o) for s in c.slots for o, g in enumerate(s.positions)}
        print(f"== {ex.id} k={k} {order} correct={rec['diagnosis']['correct']}: {rec['text']}", flush=True)
        if not show:
            continue
        for st in rec["trace"]["steps"]:
            items = [f"{where[p][0]}.{where[p][1]}[{where[p][2]}]={a.tokenizer.decode([t])!r}:{pr:.2f}"
                     for p, t, pr in zip(st["positions"], st["tokens"], st["probs"])]
            extra = f"   forced {len(st['forced'])}" if st["forced"] else ""
            print(f"  step {st['step']:2d}: " + "  ".join(items) + extra)
