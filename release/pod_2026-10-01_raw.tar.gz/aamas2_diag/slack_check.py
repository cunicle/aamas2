"""Diagnostic: how much of the skeleton error is surplus-mask overfill?

Per record: slots whose own shortest gold value is shorter than the parameter's slot
(oracle length = longest gold value of that parameter over the calls) have "slack".
Reports accuracy / CCER overall and on items without any slack, and the share of
wrong_value errors that sit in a slot with slack.

  python slack_check.py <model_id> <results.jsonl> [...]
"""
import json
import sys
from collections import defaultdict

sys.path.insert(0, "/workspace/aamas2")
from transformers import AutoTokenizer

from ptcdiag.data import load_examples
from ptcdiag.decoding.constraints import _param_type, oracle_lengths, value_text
from ptcdiag.eval.taxonomy import is_cross_call

tok = AutoTokenizer.from_pretrained(sys.argv[1], trust_remote_code=True)
exs = {e.id: e for s in ("bfcl:parallel", "bfcl:parallel_multiple") for e in load_examples(s, "data/bfcl")}
try:
    exs.update({e.id: e for e in load_examples("probe:data/paraprobe.jsonl", "data/bfcl")})
except Exception:
    pass

_slack_cache = {}


def slack(ex):
    if ex.id not in _slack_cache:
        L = oracle_lengths(tok, ex)
        out = {}
        for gi, (f, params) in enumerate(ex.gold_calls):
            for p, acc in params.items():
                vals = [a for a in acc if a != ""]
                if vals:
                    t = _param_type(ex, f, p)
                    own = min(len(tok(value_text(v, t), add_special_tokens=False)["input_ids"]) for v in vals)
                    out[gi, p] = L[p] - own
        _slack_cache[ex.id] = out
    return _slack_cache[ex.id]


groups = defaultdict(list)
for path in sys.argv[2:]:
    for line in open(path):
        r = json.loads(line)
        if r["mode"] == "skeleton" and r["id"] in exs:
            groups[(path.split("/")[-2] + "/" + path.split("/")[-1], r["cfg_tag"])].append(r)

print("| file | cfg | n | set_acc | ccer | n tight | set_acc tight | ccer tight | wrong_value in slack slot |")
print("|---|---|---|---|---|---|---|---|---|")
for (f, tag), rs in sorted(groups.items()):
    tight = [r for r in rs if not any(v > 0 for v in slack(exs[r["id"]]).values())]
    acc = lambda xs: sum(r["diagnosis"]["correct"] for r in xs) / max(len(xs), 1)  # noqa: E731
    cc = lambda xs: sum(is_cross_call(r["diagnosis"]["labels"]) for r in xs) / max(len(xs), 1)  # noqa: E731
    wv = [(r, d) for r in rs for d in r["diagnosis"]["details"] if d["label"] == "wrong_value"]
    in_slack = sum(slack(exs[r["id"]]).get((d["gold"], d["param"]), 0) > 0 for r, d in wv)
    print(f"| {f} | {tag} | {len(rs)} | {acc(rs):.3f} | {cc(rs):.3f} | {len(tight)} | {acc(tight):.3f} | "
          f"{cc(tight):.3f} | {in_slack}/{len(wv)} |")
