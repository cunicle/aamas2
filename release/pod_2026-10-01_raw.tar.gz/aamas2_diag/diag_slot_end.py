"""Diagnostic (not part of the repo): with the gold value teacher-forced into each slot,
what does the model want at the next slot position? Compares P(pad) with P(closer)."""
import math
import sys

import torch

sys.path.insert(0, "/workspace/aamas2")
from ptcdiag.data import load_examples
from ptcdiag.decoding.adapters import load_adapter
from ptcdiag.decoding.constraints import STRING_TYPES, build_skeleton
from ptcdiag.prompting import render_prompt

model_id, B = sys.argv[1], (int(sys.argv[2]) if len(sys.argv) > 2 else None)
a = load_adapter(model_id)
tok = a.tokenizer
V = None
for ex in load_examples("bfcl:parallel", "data/bfcl")[:3] + load_examples("bfcl:parallel_multiple", "data/bfcl")[:2]:
    prompt = a.encode(render_prompt(tok, ex))
    P = len(prompt)
    gen_ids, slots = build_skeleton(tok, ex, a.mask_id)
    G = a.canvas_length(P, 256, B) - P
    gen = gen_ids + [a.pad_id] * (G - len(gen_ids))
    gold = {(ci, p): acc for ci, (f, params) in enumerate(ex.gold_calls) for p, acc in params.items()}
    for s in slots:
        val = next(v for v in gold[(s.call, s.param)] if v != "")
        vtok = tok(str(val) if not isinstance(val, bool) else str(val).lower(), add_special_tokens=False)["input_ids"]
        if len(vtok) >= len(s.positions):
            continue
        for j, g in enumerate(s.positions):
            gen[g] = vtok[j] if j < len(vtok) else a.mask_id
    x = torch.tensor(list(prompt) + gen, device=a.device)[None]
    for s in slots:
        val = next(v for v in gold[(s.call, s.param)] if v != "")
        vlen = len(tok(str(val), add_special_tokens=False)["input_ids"])
        if vlen >= len(s.positions):
            continue
        pos = P + s.positions[vlen]
        we = (math.ceil((pos + 1) / B) * B) if (B and a.absolute_blocks) else None
        with torch.no_grad():
            pr = torch.softmax(a.logits(x, we)[pos].float(), -1)
        V = pr.shape[0]
        texts = tok.batch_decode([[i] for i in range(min(V, len(tok)))])
        closers = ['"'] if s.type in STRING_TYPES else [",", "}"]
        pc = sum(float(pr[i]) for i, t in enumerate(texts) if any(t.startswith(c) for c in closers))
        top = pr.topk(4)
        tops = ", ".join(f"{texts[i]!r}:{v:.2f}" for v, i in zip(top.values.tolist(), top.indices.tolist()))
        print(f"{ex.id:22s} {s.call}.{s.param:12s} value={str(val)[:18]!r:20s} "
              f"P(pad)={float(pr[a.pad_id]):.1e}  P(closer)={pc:.2f}  top: {tops}", flush=True)
